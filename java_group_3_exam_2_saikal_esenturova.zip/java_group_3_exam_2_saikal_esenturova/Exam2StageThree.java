import java.util.Random;
import java.util.Scanner;

public class Exam2StageThree{

	static int sumUser = 0;
	static int sumComputer = 0;
	static int resultUser = 0;
	static int resultComputer = 0;
	static int winnerUser = 0; 
	static int winnerComputer = 0;
	static int sumResultUser = 0; 
	static int sumResultComputer = 0;
	static int[]arrayUser = new int[4];
	static int[]arrayUserSum = new int[4];
	static int[]arrayUserResult = new int[4];
	static int[]arrayComp = new int[4];
	static int[]arrayCompSum = new int[4]; 
	static int[]arrayCompResult = new int[4];	

	public static void main(String[]args){

		//String templ = "%d - abs(%d - %d) * 2: %d points";

		//int game=0;
		
		for(int game=1; game<=3; game++){	
			Random r = new Random();
			System.out.print("Predict amount of points (2..12): ");
			//user
			Scanner sc = new Scanner(System.in);
			int predictedNumber = sc.nextInt();
			//array[] = {predictedNumber, predictedNumber, predictedNumber};
			arrayUser[game] = predictedNumber;
			System.out.println("User rolls the dices..");
			int aBox = r.nextInt(6)+1;
			int bBox = r.nextInt(6)+1;
			printDice(aBox,bBox);
			sumUser = (aBox+bBox);
			arrayUserSum[game] = sumUser;
			resultUser = sumUser - Math.abs(sumUser-predictedNumber) *2;
			arrayUserResult[game] = resultUser;
			sumResultUser = sumResultUser + resultUser;
			System.out.println();


			//computer
			int compNumber = r.nextInt(11)+2;
			arrayComp[game] = compNumber;
			System.out.println("Computer predicted "+compNumber+" points");
			System.out.println("Computer rolls the dices..");
			int cBox = r.nextInt(6)+1;
			int dBox = r.nextInt(6)+1;
			printDice(cBox,dBox);
			sumComputer = (cBox+dBox);
			arrayCompSum[game] = sumComputer;
			resultComputer = sumComputer - Math.abs(sumComputer-compNumber) *2;
			arrayCompResult[game] = resultComputer;
			sumResultComputer = sumResultComputer + sumResultUser;

			System.out.println();
			System.out.println("------------ Current score ------------");
			System.out.println("User:         "+resultUser+" points");
			System.out.println("Computer:     "+resultComputer+" points");

			winnerUser = resultUser - resultComputer;
			winnerComputer = resultComputer - resultUser;

			if(resultUser>resultComputer){
				System.out.println("User is ahead by " +winnerUser+ " points.");
			}
			else if(resultUser<resultComputer){
				System.out.println("Computer is ahead by " +winnerComputer+ " points.");
			}
			else if(resultUser==resultComputer) System.out.println("They are DRAW for now");
			System.out.println("----------------------------------------");

			if(game==3){
				System.out.println("---------------- Finish game ---------------");
				System.out.println();
				System.out.println("Round  |         User |       Computer");
				System.out.println("-------------+--------------+----------------");
				String temp1 = "- %d - | Predicted: %-10d  | Predicted: %d\n      | Dice: %-10d | Dice: %d\n      | Result: %-10d | Result: %d";
				for(int i=1;i<=3;i++){
					String msg1 = String.format(temp1, i, arrayUser[i], arrayComp[i], arrayUserSum[i], arrayCompSum[i], arrayUserResult[i], arrayCompResult[i]);
					System.out.println(msg1);
					System.out.println("-------------+--------------+----------------");

				}
				
				System.out.println("Total  | Points:  "+ sumResultUser +" | Points:      "+sumResultComputer);
				if(sumResultUser>sumResultComputer){
					winnerUser = sumResultUser-sumResultComputer;
					System.out.println("User wins "+ winnerUser +" points more");
					System.out.println("Congratulations!");	
				}
				else {
					System.out.println("Computer wins "+ winnerUser +" points more");
				}
				
			}	
		}
	}	

	public static void printDice(int dice1, int dice2){
		if(dice1==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice1==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice1==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice1==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice2==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice2==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
	}
}