import java.util.Random;
import java.util.Scanner;

public class Exam2StageOne{

	public static void main(String[]args){
		System.out.println("--- Start game ---");

		System.out.print("Predict amount of points (2..12): ");
		Scanner sc = new Scanner(System.in);
		int predictedNumber = sc.nextInt();
		
		System.out.println("User rolls the dices..");
		Random r = new Random();
		int aBox = r.nextInt(6)+1;
		int bBox = r.nextInt(6)+1;

		int sum = 0;
		int result = 0;
		
		printDice(aBox,bBox);
		
		sum = (aBox+bBox); 
		System.out.println("On the side fell "+sum+" points");
		
		result = sum - Math.abs(sum-predictedNumber) *2;
		String templ = "%d - abs(%d - %d) * 2: %d points";
		String msg = String.format(templ, sum, sum, predictedNumber, result);
		System.out.println(msg);
		
		if(result>0) System.out.println("User wins!");
		else System.out.println("User lost!");
	}
	public static void printDice(int dice1, int dice2){
		if(dice1==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice1==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice1==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice1==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice2==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice2==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
	}
	/*public static int rollTheDice(){
		Random r = new Random();
		int side1 = r.nextInt(6)+1;
		int side2 = r.nextInt(6)+1;
		return;
	}*/
}