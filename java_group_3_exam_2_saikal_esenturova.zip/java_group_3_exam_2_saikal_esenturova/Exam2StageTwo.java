import java.util.Random;
import java.util.Scanner;

public class Exam2StageTwo{

	public static void main(String[]args){
		Random r = new Random();
		int sumUser = 0;
		int sumComputer = 0;
		int resultUser = 0;
		int resultComputer = 0;
		int winnerUser = 0; 
		int winnerComputer = 0;

		String templ = "%d - abs(%d - %d) * 2: %d points";


		System.out.println("--- Start game ---");

		System.out.print("Predict amount of points (2..12): ");
		//user
		Scanner sc = new Scanner(System.in);
		int predictedNumber = sc.nextInt();
		System.out.println("User rolls the dices..");
		int aBox = r.nextInt(6)+1;
		int bBox = r.nextInt(6)+1;
		printDice(aBox,bBox);
		sumUser = (aBox+bBox);
		System.out.println("On the dice fell "+sumUser+" points");

		resultUser = sumUser - Math.abs(sumUser-predictedNumber) *2;
		String msg = String.format(templ, sumUser, sumUser, predictedNumber, resultUser);
		System.out.println(msg);

		System.out.println();
		//computer
		int compNumber = r.nextInt(11)+2;
		System.out.println("Computer predicted "+compNumber+" points");
		System.out.println("Computer rolls the dices..");
		int cBox = r.nextInt(6)+1;
		int dBox = r.nextInt(6)+1;
		printDice(cBox, dBox);
		sumComputer = (cBox+dBox); 
		System.out.println("On the dice fell "+sumComputer+" points");
		resultComputer = sumComputer - Math.abs(sumComputer-compNumber) *2;
		msg = String.format(templ, sumComputer, sumComputer, compNumber, resultComputer);
		System.out.println(msg);
		
		System.out.println();
		winnerUser = resultUser - resultComputer;
		winnerComputer = resultComputer - resultUser;

		if(resultUser>resultComputer){
			System.out.println("User win " +winnerUser+ " points more.");
			System.out.println("Congratulations!");
		}
		else if(resultUser<resultComputer){
			System.out.println("Computer win " +winnerComputer+ " points more.");
			System.out.println("User lost!");
		}
		else if(resultUser==resultComputer) System.out.println("DRAW"); 
	}
	public static void printDice(int dice1, int dice2){
		if(dice1==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice1==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice1==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice1==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice1==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==1){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|       |");
			System.out.println("+-------+");
		}
		if(dice2==2){
			System.out.println("+-------+");
			System.out.println("|#      |");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==3){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|      #|");
			System.out.println("+--------+");
		}
		if(dice2==4){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|       |");
			System.out.println("|#     #|");
			System.out.println("+--------+");
		}
		if(dice2==5){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|   #   |");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
		if(dice2==6){
			System.out.println("+-------+");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("|#     #|");
			System.out.println("+-------+");
		}
	}
}